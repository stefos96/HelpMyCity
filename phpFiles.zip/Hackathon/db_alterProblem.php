<?php
$servername = "db11.grserver.gr:3306";
$username = "stefos96";
$password = "stefos1996";
$database = "HelpMyCity";

$mysqli = new mysqli($servername, $username, $password, $database);

if ($mysqli->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully\n";


$name = $mysqli->real_escape_string($_GET['name']);
$lastname = $mysqli->real_escape_string($_GET['lastname']);
$prdescription = $mysqli->real_escape_string($_GET['prdescription']);
$title = $mysqli->real_escape_string($_GET['title']);


$sql = "INSERT INTO problems (name, lastname, prdescription, title) VALUES ('$name','$lastname','$prdescription','$title')";

if ($mysqli->query($sql) === true){	
	echo "Submited successfully\n";
}





?>