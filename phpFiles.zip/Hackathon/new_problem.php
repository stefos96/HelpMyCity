<?php
$servername = "db11.grserver.gr:3306";
$username = "stefos96";
$password = "stefos1996";
$database = "HelpMyCity";

$mysqli = new mysqli($servername, $username, $password, $database);

if ($mysqli->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully\n";


$name = $mysqli->real_escape_string($_GET['name']);
$lastname = $mysqli->real_escape_string($_GET['lastname']);
$prdescription = $mysqli->real_escape_string($_GET['prdescription']);
$title = $mysqli->real_escape_string($_GET['title']);
$prdescription = $mysqli->real_escape_string($_GET['prdescription']);
$report_date = $mysqli->real_escape_string($_GET['date']);
$latitude = $mysqli->real_escape_string($_GET['latitude']);
$longitude = $mysqli->real_escape_string($_GET['longitude']);



$sql = "INSERT INTO problems (name, lastname, prdescription, title, latitude, longitude, report_date) VALUES ('$name','$lastname','$prdescription','$title', '$latitude', '$longitude', '$report_date')";

if ($mysqli->query($sql) === true){	
	echo "Submited successfully\n";
}





?>