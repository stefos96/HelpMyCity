<?php
require_once __DIR__ . '/db_settings.php'; // Importing the settings file
	$response = array();
	$prid = $_GET["prid"];
	$db = new DB_CONNECT();// Creating a new object that connects to the database
	// SQL Query to return the object with the prid
	$result = mysql_query("SELECT * FROM problems WHERE prid = '$prid'") or die(mysql_error()); 
	$row = mysql_fetch_array($result);
	$response["problems"] = array();             
	$problem = array();                                 //returning all the data from the database
	$problem["prid"] = $row["prid"];                    //into array to run in the function json_encode()
	$problem["name"] = $row["name"];					   //that will print the database as JSONObject
	$problem["lastname"] = $row["lastname"];
	$problem["title"] = $row["title"];
	$problem["prdescription"] = $row["prdescription"];
	$problem["report_date"] = $row["report_date"];
	$problem["latitude"] = $row["latitude"];
	$problem["longitude"] = $row["longitude"];
	array_push($response["problems"], $problem);
	echo json_encode($response);							
?>