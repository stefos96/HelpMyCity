<?php
//Setting for effective connection to the database
define('DB_USER', "stefos96");
define('DB_PASSWORD', "stefos1996");
define('DB_DATABASE', "HelpMyCity");
define('DB_SERVER', "db11.grserver.gr:3306");

//Creating the class that allows us to connect to the database
class DB_CONNECT {
    function __construct() {
        $this->connect();
    }
    function __destruct() {
        // closing db connection
        $this->close();
    }
    function connect() {
        // import database connection variables
        // Connecting to mysql database
        $con = mysql_connect(DB_SERVER, DB_USER, DB_PASSWORD) or die(mysql_error());
 
        // Selecing database
        $db = mysql_select_db(DB_DATABASE) or die(mysql_error()) or die(mysql_error());
 
        // returing connection cursor
        return $con;
    }
    function close() {
        // closing db connection
        mysql_close();
    }
}
?>